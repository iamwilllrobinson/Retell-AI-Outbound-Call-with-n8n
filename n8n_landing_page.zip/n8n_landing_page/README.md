# Toothsi Smile Studio - Landing Page

A modern, responsive landing page for a dental clinic with appointment booking functionality.

## 🦷 Features

### Design & Layout
- **Clean Hero Section** with clinic branding and call-to-action
- **Services Section** highlighting dental services (Cleaning, Braces, Cosmetic Dentistry)
- **Contact Form** with appointment booking functionality
- **Sticky Header** with navigation
- **Responsive Design** that works on all devices
- **Modern UI** with soft blue and white theme

### Functionality
- **Form Validation** for all input fields
- **API Integration** using fetch() to submit form data
- **Success Modal** with confirmation message
- **Smooth Scrolling** navigation
- **Mobile Responsive** design using CSS Grid and Flexbox

## 🚀 Getting Started

### Prerequisites
- A modern web browser
- No additional dependencies required (uses vanilla HTML, CSS, and JavaScript)

### Installation
1. Clone or download the project files
2. Open `index.html` in your web browser
3. The landing page will load with all functionality ready to use

### File Structure
```
n8n_landing_page/
├── index.html          # Main HTML file
├── styles.css          # CSS styling and responsive design
├── script.js           # JavaScript functionality
└── README.md           # Project documentation
```

## 📋 Form Features

### Contact Form Fields
- **Name** (required, minimum 2 characters)
- **Email** (required, email format validation)
- **Phone Number** (required, basic phone validation)

### Form Submission
- Validates all fields before submission
- Sends POST request to: `https://lakshit1996.app.n8n.cloud/webhook-test/ee4111fc-0b05-447a-a6b3-0b8b1c0e19c2`
- Displays loading state during submission
- Shows success modal on successful submission
- Handles errors gracefully with user-friendly messages

## 🎨 Design System

### Color Palette
- **Primary Blue**: `#1e40af` (Deep blue for headings and CTAs)
- **Secondary Blue**: `#3b82f6` (Lighter blue for gradients)
- **Background**: `#f8fafc` (Light gray background)
- **Text**: `#333` (Dark gray for body text)
- **Muted Text**: `#64748b` (Gray for secondary text)

### Typography
- **Font Family**: Inter (Google Fonts)
- **Weights**: 300, 400, 500, 600, 700
- **Responsive sizing** for different screen sizes

### Components
- **Cards** with rounded corners and shadows
- **Buttons** with gradient backgrounds and hover effects
- **Form inputs** with focus states and validation styling
- **Modal** with backdrop blur effect

## 📱 Responsive Design

### Breakpoints
- **Desktop**: 1200px and above
- **Tablet**: 768px - 1199px
- **Mobile**: Below 768px
- **Small Mobile**: Below 480px

### Responsive Features
- **Flexible Grid Layout** that adapts to screen size
- **Mobile-first navigation** with collapsible menu
- **Scalable typography** and spacing
- **Touch-friendly** buttons and form elements

## 🔧 Customization

### Updating Content
1. **Clinic Information**: Edit the clinic name, tagline, and contact details in `index.html`
2. **Services**: Modify the services section to match your offerings
3. **Colors**: Update the CSS custom properties in `styles.css`
4. **API Endpoint**: Change the webhook URL in `script.js`

### Adding Features
- **Additional Form Fields**: Add new input fields and validation in `script.js`
- **New Sections**: Create additional HTML sections and corresponding CSS
- **Animations**: Add CSS animations or JavaScript interactions
- **Analytics**: Integrate Google Analytics or other tracking tools

## 🛠️ Technical Details

### JavaScript Features
- **ES6+ Syntax** with async/await for API calls
- **Form Validation** with real-time error display
- **Event Handling** for user interactions
- **Modal Management** with keyboard and click handlers
- **Smooth Scrolling** implementation

### CSS Features
- **CSS Grid** and **Flexbox** for layouts
- **CSS Custom Properties** for consistent theming
- **Media Queries** for responsive design
- **CSS Transitions** and transforms for animations
- **Backdrop Filter** for modern glass effects

### Browser Support
- **Modern Browsers**: Chrome, Firefox, Safari, Edge (latest versions)
- **Mobile Browsers**: iOS Safari, Chrome Mobile
- **Fallbacks**: Graceful degradation for older browsers

## 🚀 Deployment

### Static Hosting
This landing page can be deployed to any static hosting service:

1. **Netlify**: Drag and drop the folder to Netlify
2. **Vercel**: Connect your repository to Vercel
3. **GitHub Pages**: Push to a GitHub repository and enable Pages
4. **AWS S3**: Upload files to an S3 bucket with static website hosting

### Custom Domain
- Configure your custom domain in your hosting provider
- Update any absolute URLs in the code if necessary

## 📞 Support

For questions or issues:
- Check the browser console for JavaScript errors
- Verify the API endpoint is accessible
- Test form submission with valid data
- Ensure all files are in the same directory

## 📄 License

This project is open source and available under the MIT License.

---

**Built with ❤️ for Toothsi Smile Studio** 